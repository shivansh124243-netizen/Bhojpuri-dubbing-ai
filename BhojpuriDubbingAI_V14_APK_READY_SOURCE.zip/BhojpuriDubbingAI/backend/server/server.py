#!/usr/bin/env python3
"""Local HTTP bridge for the Android client. Streams large uploads to disk."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, subprocess, threading, uuid, urllib.parse, time, shutil

ROOT=Path(os.getenv('DUB_WORK_ROOT','jobs')).resolve()
ROOT.mkdir(parents=True,exist_ok=True)
JOBS={}; LOCK=threading.Lock(); BASE=Path(__file__).resolve().parents[1]
MAX_UPLOAD=int(os.getenv('DUB_MAX_UPLOAD_BYTES', str(25*1024**3)))

def send(h,code,obj):
    raw=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(code)
    h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(raw))); h.end_headers(); h.wfile.write(raw)

def write_error(wd,msg):
    (wd/'status.json').write_text(json.dumps({'state':'error','progress':0,'error':msg,'updated_at':time.time()},ensure_ascii=False,indent=2),encoding='utf-8')

def launch(jid,payload):
    wd=ROOT/jid; inp=wd/'input.mp4'; out=wd/'dubbed.mp4'
    env=os.environ.copy(); env['BHOJPURI_VOICE']=payload.get('voice','Bhojpuri (Male)')
    def run():
        try:
            p=subprocess.Popen(['python','-m','pipeline.dub_movie',str(inp),str(out),'--work',str(wd)],cwd=str(BASE),env=env)
            with LOCK: JOBS[jid]=p
            rc=p.wait()
            if rc!=0 and not (wd/'status.json').exists(): write_error(wd,f'pipeline exit code {rc}')
        except Exception as e:
            write_error(wd,f'{type(e).__name__}: {e}')
    threading.Thread(target=run,daemon=True).start()

class H(BaseHTTPRequestHandler):
    def save_body(self,path):
        length=int(self.headers.get('Content-Length','0') or 0)
        if length<=0: raise ValueError('Content-Length is required')
        if length>MAX_UPLOAD: raise ValueError(f'upload too large: {length} bytes')
        tmp=path.with_suffix('.uploading')
        remaining=length
        with tmp.open('wb') as out:
            while remaining:
                chunk=self.rfile.read(min(1024*1024,remaining))
                if not chunk: raise ConnectionError('client upload ended early')
                out.write(chunk); remaining-=len(chunk)
        tmp.replace(path)

    def do_POST(self):
        path=urllib.parse.urlsplit(self.path).path
        try:
            if path=='/upload':
                q=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                jid=uuid.uuid4().hex[:12]; wd=ROOT/jid; wd.mkdir(parents=True,exist_ok=True)
                self.save_body(wd/'input.mp4')
                (wd/'status.json').write_text(json.dumps({'state':'queued','progress':0,'updated_at':time.time()},ensure_ascii=False),encoding='utf-8')
                threading.Thread(target=launch,args=(jid,{'voice':(q.get('voice') or ['Bhojpuri (Male)'])[0]},),daemon=True).start()
                send(self,202,{'job_id':jid}); return
            if path.startswith('/pause/') or path.startswith('/resume/'):
                jid=path.split('/')[-1]; wd=ROOT/jid
                if not wd.exists(): send(self,404,{'error':'job not found'}); return
                flag=wd/'PAUSE'
                if path.startswith('/pause/'):
                    flag.touch(); action='paused'
                else:
                    flag.unlink(missing_ok=True); action='resumed'
                send(self,200,{'job_id':jid,'state':action}); return
            send(self,404,{'error':'not found'})
        except Exception as e:
            send(self,400,{'error':f'{type(e).__name__}: {e}'})

    def do_GET(self):
        path=urllib.parse.urlsplit(self.path).path
        if path.startswith('/status/'):
            jid=path.split('/')[-1]; p=ROOT/jid/'status.json'
            data=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'state':'starting','progress':0}
            proc=JOBS.get(jid); data['process_alive']=bool(proc and proc.poll() is None)
            data['paused']=(ROOT/jid/'PAUSE').exists(); send(self,200,data); return
        if path.startswith('/download/'):
            f=ROOT/path.split('/')[-1]/'dubbed.mp4'
            if not f.exists(): send(self,404,{'error':'output not ready'}); return
            self.send_response(200); self.send_header('Content-Type','video/mp4'); self.send_header('Content-Length',str(f.stat().st_size)); self.end_headers()
            with f.open('rb') as r:
                while (b:=r.read(1024*1024)): self.wfile.write(b)
            return
        send(self,404,{'error':'not found'})

    def log_message(self,*args): pass

if __name__=='__main__':
    ThreadingHTTPServer(('0.0.0.0',int(os.getenv('DUB_PORT','8765'))),H).serve_forever()
