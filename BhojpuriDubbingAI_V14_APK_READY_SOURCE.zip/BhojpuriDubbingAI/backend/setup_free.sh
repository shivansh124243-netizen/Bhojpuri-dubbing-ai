#!/usr/bin/env bash
set -e
python3 -m pip install -r requirements.txt
python3 -m pip install huggingface_hub
# FFmpeg must be installed separately and available on PATH.
# Svara model is downloaded automatically by Transformers on first run.
# Translation uses a local Ollama server by default (no paid API).
echo 'Setup complete. Install FFmpeg, start local Ollama, and run dub_movie.py.'
