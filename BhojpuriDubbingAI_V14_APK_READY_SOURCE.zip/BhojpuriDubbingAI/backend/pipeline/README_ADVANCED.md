# Advanced features

These features are integrated as opt-in modules. They are disabled by default so the basic dubbing path stays reliable.

## Speaker diarization
Uses `pyannote.audio` Community-1 locally. It identifies speaker turns. The pretrained pipeline may require a Hugging Face token/accepted model conditions; set `HF_TOKEN`.

## Voice cloning
Uses an optional local XTTS-v2 adapter. Put authorized reference WAV files in `voice_refs/` named like `SPEAKER_00.wav`. Install the local TTS runtime and set `voice_cloning=true`.

**Use only voices you have permission to clone.**

## M&E/source separation
Uses Demucs `--two-stems=vocals` to produce an accompaniment track. This is useful for music/accompaniment but is **not guaranteed to perfectly remove movie dialogue**; movie speech can remain or artifacts can appear.

## Lip sync
Uses an existing Wav2Lip checkout. Set `WAV2LIP_DIR` and `WAV2LIP_CHECKPOINT`. The model/runtime is not bundled.

## Emotion
The pipeline preserves an `emotion` field if a future emotion detector/voice engine supplies one. The current Svara adapter does not claim full emotion cloning.

## Subtitles
The transcript/translation JSON is retained per chunk and can be converted to Bhojpuri SRT/ASS in a later render step. The core files contain all timing data needed for this.
