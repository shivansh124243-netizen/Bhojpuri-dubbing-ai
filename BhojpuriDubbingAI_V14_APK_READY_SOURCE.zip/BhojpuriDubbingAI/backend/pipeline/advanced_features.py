#!/usr/bin/env python3
"""Optional advanced modules for the dubbing pipeline.

All modules are opt-in. They use local/open-source tooling where possible and
fail with a clear message when their model/runtime is not installed.
"""
import json, os, subprocess
from pathlib import Path


def run(cmd):
    subprocess.run(cmd, check=True)


def separate_background(audio_in, out_dir, model=None):
    """Create accompaniment.wav with Demucs. Best effort for music/effects.
    Demucs separates vocals from accompaniment; it is not a guaranteed clean
    movie dialogue/M&E separator.
    """
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / "accompaniment.wav"
    if out.exists(): return out
    model = model or os.getenv("DEMUCS_MODEL", "htdemucs")
    run([os.getenv("DEMUCS_BIN", "python"), "-m", "demucs", "--two-stems=vocals", "-n", model, "-o", str(out_dir), str(audio_in)])
    candidates = list(out_dir.rglob("no_vocals.wav"))
    if not candidates: raise FileNotFoundError("Demucs did not produce no_vocals.wav")
    candidates[0].replace(out)
    return out


def diarize(audio, out_json, hf_token=None):
    """Run pyannote Community-1 locally and save speaker turns."""
    try:
        from pyannote.audio import Pipeline
    except ImportError as e:
        raise RuntimeError("Install pyannote.audio to enable speaker diarization") from e
    token = hf_token or os.getenv("HF_TOKEN")
    if not token:
        raise RuntimeError("HF_TOKEN is required for the pretrained pyannote Community-1 pipeline")
    pipe = Pipeline.from_pretrained("pyannote/speaker-diarization-community-1", token=token)
    diar = pipe(str(audio))
    turns=[]
    annotation = getattr(diar, "speaker_diarization", diar)
    for turn, _, speaker in annotation.itertracks(yield_label=True):
        turns.append({"start": float(turn.start), "end": float(turn.end), "speaker": str(speaker)})
    Path(out_json).write_text(json.dumps(turns, ensure_ascii=False, indent=2), encoding="utf-8")
    return turns


def clone_tts(text, outwav, speaker_wav, language="bho"):
    """Optional XTTS-v2 voice cloning adapter. Requires local TTS package/model."""
    try:
        from TTS.api import TTS
    except ImportError as e:
        raise RuntimeError("Install TTS to enable XTTS-v2 voice cloning") from e
    model = os.getenv("XTTS_MODEL", "tts_models/multilingual/multi-dataset/xtts_v2")
    tts = TTS(model_name=model, progress_bar=False, gpu=os.getenv("XTTS_GPU", "0") == "1")
    tts.tts_to_file(text=text, speaker_wav=str(speaker_wav), language=language, file_path=str(outwav))
    return Path(outwav)


def lip_sync(video, audio, out_video):
    """Run an installed Wav2Lip checkout through its inference.py script."""
    repo = os.getenv("WAV2LIP_DIR", "").strip()
    checkpoint = os.getenv("WAV2LIP_CHECKPOINT", "").strip()
    if not repo or not checkpoint:
        raise RuntimeError("Set WAV2LIP_DIR and WAV2LIP_CHECKPOINT to enable lip-sync")
    inference = Path(repo) / "inference.py"
    if not inference.exists(): raise FileNotFoundError(f"Wav2Lip inference.py not found: {inference}")
    run(["python", str(inference), "--checkpoint_path", checkpoint, "--face", str(video), "--audio", str(audio), "--outfile", str(out_video)])
    return Path(out_video)
