plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.bhojpuridubbingai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.bhojpuridubbingai"
        minSdk = 24
        targetSdk = 35
        versionCode = 8
        versionName = "8.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.12.0")
}
