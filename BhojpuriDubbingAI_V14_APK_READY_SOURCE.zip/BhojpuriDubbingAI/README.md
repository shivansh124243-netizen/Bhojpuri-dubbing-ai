# BhojpuriDubbingAI

A local/open-source Hindi-movie → Bhojpuri dubbing pipeline.

## Core flow
Video → Hindi ASR → natural Bhojpuri translation → Bhojpuri TTS → timestamp sync → FFmpeg MP4.

The pipeline processes movies in 15-minute chunks and writes checkpoints so completed chunks can be reused after a stop/restart.

### Natural voice
The default Svara-TTS v1 model supports `Bhojpuri (Male)` and `Bhojpuri (Female)` voices and expressive style tags. It is an open Apache-2.0 model; the large weights are downloaded separately rather than embedded in this source archive.

### Important audio note
Without a clean music/effects (M&E) stem, simply lowering the original audio can leave faint Hindi speech underneath. The project therefore supports three modes: `quiet_original`, `mute`, and `external` background audio. A true clean movie mix requires a separate M&E/source-separation step.

### Not included
Exact actor-voice cloning is not part of the default pipeline. If voice cloning is added later, use only voices for which you have the necessary rights/consent.

See `backend/RUNNING.md` for the local server and model setup.
